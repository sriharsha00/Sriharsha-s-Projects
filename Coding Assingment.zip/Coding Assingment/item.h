#ifndef ITEM_H
#define ITEM_H

#include <string>
using namespace std;

class Item{
public:
    Item(string ItemDescription, double cost);
    Item();
    void setDescription (string ItemDescription);
    void setCost (double cost);
    string getDescription();
    double getCost();
    friend ostream &operator<<(ostream &output, Item& it4); 
private:
    string description;
    double rate;
};

#endif