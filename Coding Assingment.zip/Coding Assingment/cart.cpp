#include <iostream>
#include "cart.h"
#include "item.h"
#include <vector>
using namespace std;

void GroceryCart::insertItem(Item it) {
 cart.push_back(it);   
}

void GroceryCart::deleteItem(Item it) {
    int i;
    for (i = 0; i < cart.size(); i++) {
        if (cart.at(i).getDescription() == it.getDescription()) {
           cart.erase(cart.begin() + i); 
        }    
    }
}

int GroceryCart::getItemCount() {
    count = cart.size();
    return count;
}

bool GroceryCart::isCartEmpty() {
    return (cart.size() == 0);
}

double GroceryCart::calcTotalCost() {
    double i;
    double sum = 0;
    for (i = 0; i < cart.size(); ++i) {
       sum = sum + cart.at(i).getCost(); 
    }
    return sum;
}

 bool operator==( GroceryCart& cart3, GroceryCart& cart4){
    for (int i = 0; i < cart3.getSize(); ++i) {
        if (cart3.getItemAt(i).getDescription()!= cart4.getItemAt(i).getDescription()) {
             return false;   
        }

      else {
        return true;
      }  

    }
}

double GroceryCart::getSize() {
    return cart.size();
}

Item GroceryCart::getItemAt(double i) {
    return cart.at(i);
}