#ifndef CART_H
#define CART_H

#include "item.h"
#include <vector>

class GroceryCart {
    public:
        void insertItem(Item);
        void deleteItem(Item);
        int getItemCount();
        bool isCartEmpty();
        double calcTotalCost();
        friend bool operator==(GroceryCart& cart3, GroceryCart& cart4);
        double getSize();
        Item getItemAt(double);

    private:
        double count;
        double cost;
        std::vector<Item> cart;    
};

#endif