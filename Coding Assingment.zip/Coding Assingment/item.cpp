#include <iostream>
#include <string>
using namespace std;

#include "item.h"

Item::Item(string ItemDescription, double cost) {
    description = ItemDescription;
    rate = cost;
}

Item::Item() {
    description = "Invalid item";
    rate = 0.0;
}

void Item::setDescription(string ItemDescription) {
    description = ItemDescription;
}

void Item::setCost(double cost) {
    rate = cost;
}

string Item::getDescription() {
    return description;
}

double Item::getCost() {
    return rate;
}

ostream &operator<<(ostream &output, Item& it4) {
    output<<it4.getDescription() << ":$" <<it4.getCost();
    return output;
} 